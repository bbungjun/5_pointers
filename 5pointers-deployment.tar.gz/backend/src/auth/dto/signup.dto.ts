// login.dto.ts
export class LoginDto {
    email: string;
    password: string;
  }
  
  // signup.dto.ts
  export class SignupDto {
    email: string;
    password: string;
  }