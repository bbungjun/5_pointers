export const musicLibrary = [
  {
    id: 1,
    title: "wedding-01",
    data: "/music/wedding-01.mp3"
  },
  {
    id: 2,
    title: "wedding-02",
    data: "/music/wedding-02.mp3"
  },
  {
    id: 3,
    title: "wedding-03",
    data: "/music/wedding-03.mp3"
  },
  {
    id: 4,
    title: "wedding-04",
    data: "/music/wedding-04.mp3"
  },
  {
    id: 5,
    title: "wedding-05",
    data: "/music/wedding-05.mp3"
  },
  {
    id: 6,
    title: "wedding-06",
    data: "/music/wedding-06.mp3"
  },
  {
    id: 7,
    title: "wedding-07",
    data: "/music/wedding-07.mp3"
  }
];